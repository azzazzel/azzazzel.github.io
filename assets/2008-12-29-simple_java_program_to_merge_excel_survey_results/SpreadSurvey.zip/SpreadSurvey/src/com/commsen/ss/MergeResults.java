/**
 * Copyright © 2008 Milen Dyankov.
 *    
 * Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved.
 * 
 */
package com.commsen.ss;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import com.townleyenterprises.command.CommandListener;
import com.townleyenterprises.command.CommandOption;
import com.townleyenterprises.command.CommandParser;

public class MergeResults implements CommandListener {

	static CommandOption templateFileOption = new CommandOption("template-file", 't', true, "<filename>", "Specify the name of the template file.");
	static CommandOption resultFileOption = new CommandOption("result-file", 'r', true, "<filename>", "Specify the name of the result file.");
	static CommandOption overwriteFileOption = new CommandOption("overwrite", 'O', false, null, "Add to overwrite result file if exists.");
	static CommandOption directionOption = new CommandOption("direction", 'd', true, "<X|Y>", "Specify whether data is added in columns or rows (default is X)");
	static CommandOption skipBrokenOption = new CommandOption("skip-broken", 'S', false, null, "Add to skip broken files");
	static CommandOption[] opts = { templateFileOption, resultFileOption, overwriteFileOption, directionOption, skipBrokenOption };

	private static final String DIRECTION_X = "X";
	private static final String DIRECTION_Y = "Y";
	private static final Set<String> DIRECTION_OPTIONS = new HashSet<String>();
	static {
		DIRECTION_OPTIONS.add(DIRECTION_X);
		DIRECTION_OPTIONS.add(DIRECTION_Y);
	};

	private File templateFile;
	private File resultFile;
	private String direction = DIRECTION_X;
	private String[] files;


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MergeResults mergeResults = new MergeResults(args);
		try {
			mergeResults.merge();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public MergeResults(String[] args) {
		CommandParser commandParser = new CommandParser("MergeResults", "FILE...");
		commandParser.addCommandListener(this);
		commandParser.parse(args);

		// template file

		if (!templateFileOption.getMatched()) {
			die("Missing template file !");
		}
		templateFile = new File(templateFileOption.getArg());

		if (!templateFile.exists() || !templateFile.isFile()) {
			die("File " + templateFile.getName() + " does not exists or is not a file!");
		}

		if (!templateFile.canRead()) {
			die("Can not read file " + templateFile.getName() + "!");
		}

		// result file

		if (!resultFileOption.getMatched()) {
			die("Missing result file !");
		}

		resultFile = new File(resultFileOption.getArg());

		boolean overwriteResult = overwriteFileOption.getMatched();

		if (resultFile.exists() && !overwriteResult) {
			die("File " + resultFile.getName() + " already exists! Add -" + overwriteFileOption.getShortName() + " option to overwrite it!");
		}

		if (resultFile.exists() && !resultFile.isFile()) {
			die("Can not overwrite " + resultFile.getName() + "! It is not real file!");
		}

		if (resultFile.exists() && !resultFile.canWrite()) {
			die("Can not write to " + resultFile.getName() + "!");
		}

		try {
			FileUtils.touch(resultFile);
		} catch (IOException e) {
			die("Failed to create " + resultFile.getName() + "! " + e);
		}

		// direction

		if (directionOption.getMatched() && DIRECTION_OPTIONS.contains(directionOption.getArg().toUpperCase())) {
			direction = directionOption.getArg();
		} else {
			warn("No direction specified! Assumed direction " + direction + "!");
		}

		// files

		files = commandParser.getUnhandledArguments();
		if (!skipBrokenOption.getMatched()) {
			for (String file : files) {
				File f = new File(file);
				if (!f.exists() || !f.isFile()) {
					die("File " + f.getName() + " does not exists or is not a file! Add -" + skipBrokenOption.getShortName() + " option to ignore broken/missing files!");
				}
				if (!f.canRead()) {
					die("Can not read file " + templateFile.getName() + "! Add -" + skipBrokenOption.getShortName() + " option to ignore broken/missing files!");
				}
			}
		}

	}


	private void merge() throws FileNotFoundException, IOException {

		int minRow = -1, maxRow = -1, minCol = -1, maxCol = -1;
		List<TemplateExpression> templateExpressions = new ArrayList<TemplateExpression>();

		POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(templateFile));
		HSSFWorkbook wb = new HSSFWorkbook(fs);
		HSSFSheet sheet = wb.getSheetAt(0);
		for (Iterator<HSSFRow> rowIterator = sheet.rowIterator(); rowIterator.hasNext();) {
			HSSFRow row = rowIterator.next();
			for (Iterator<HSSFCell> cellIterator = row.cellIterator(); cellIterator.hasNext();) {
				HSSFCell cell = cellIterator.next();
				if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
					if (TemplateExpression.isTemplateExpression(cell.getStringCellValue())) {
						info("Found expression at " + cell.getCellNum() + ":" + row.getRowNum());
						maxCol = cell.getCellNum();
						maxRow = row.getRowNum();
						if (minCol < 0) minCol = maxCol;
						if (minRow < 0) minRow = maxRow;
						templateExpressions.add(new TemplateExpression(row.getRowNum(), cell.getCellNum(), cell.getStringCellValue()));
						cell.setCellValue("OK");

					}
				}
			}
		}
		if (maxRow < 0 || maxCol < 0) {
			die("NO template expressions found!");
		} else {
			info("Template expresions found in area " + minCol + ":" + minRow + " - " + maxCol + ":" + maxRow);
		}

		int step = 0;
		int currentOffset = 0;
		if (direction.equals(DIRECTION_X)) {
			step = maxCol - minCol + 1;
			currentOffset = minCol + step;
		} else if (direction.equals(DIRECTION_Y)) {
			step = maxRow - minRow + 1;
			currentOffset = minRow + step;
		} else {
			die("Imposible is nothing !!!");
		}

		for (String file : files) {
			info("processing file: " + file);
			File f = new File(file);
			POIFSFileSystem currentFS = new POIFSFileSystem(new FileInputStream(f));
			HSSFWorkbook currentWB = new HSSFWorkbook(currentFS);
			HSSFSheet currentSheet = currentWB.getSheetAt(0);
			for (TemplateExpression templateExpression : templateExpressions) {
				HSSFCell sourceCell = calculateSourceCell(currentSheet, templateExpression);
				HSSFCell destCell = calculateDescCell(sheet, templateExpression, currentOffset);
				copyCellValue(sourceCell, destCell);
			}
			currentOffset += step;
		}

		// Write the output to a file
		FileOutputStream fileOut = new FileOutputStream(resultFile);
		wb.write(fileOut);
		fileOut.close();

	}


	private HSSFCell calculateSourceCell(HSSFSheet sheet, TemplateExpression templateExpression) {
		HSSFRow row = sheet.getRow(templateExpression.getExpressionRow());
		if (row == null) return null;
		HSSFCell cell = row.getCell(templateExpression.getExpressionCol());
		return cell;
	}


	/**
	 * @param sheet
	 * @param currentOffset
	 * @param templateExpression
	 * @param destCell
	 * @return
	 */
	private HSSFCell calculateDescCell(HSSFSheet sheet, TemplateExpression templateExpression, int currentOffset) {
		HSSFCell destCell = null;
		if (direction.equals(DIRECTION_X)) {
			HSSFRow destRow = sheet.getRow(templateExpression.row);
			if (destRow == null) destRow = sheet.createRow(templateExpression.row);
			destCell = destRow.getCell((short) (currentOffset));
			if (destCell == null) destCell = destRow.createCell((short) (currentOffset));
		} else if (direction.equals(DIRECTION_Y)) {
			HSSFRow destRow = sheet.getRow(currentOffset);
			if (destRow == null) destRow = sheet.createRow(currentOffset);
			destCell = destRow.getCell(templateExpression.col);
			if (destCell == null) destCell = destRow.createCell(templateExpression.col);
		} else {
			die("Imposible is nothing !!!");
		}
		return destCell;
	}


	private void copyCellValue(HSSFCell source, HSSFCell dest) {
		if (source == null) throw new IllegalArgumentException("Source cell can not be NULL");
		if (dest == null) throw new IllegalArgumentException("Dest cell can not be NULL");

		switch (source.getCellType()) {
			case HSSFCell.CELL_TYPE_BLANK:
				dest.setCellType(HSSFCell.CELL_TYPE_BLANK);
				break;
			case HSSFCell.CELL_TYPE_BOOLEAN:
				dest.setCellValue(source.getBooleanCellValue());
				break;
			case HSSFCell.CELL_TYPE_NUMERIC:
				dest.setCellValue(source.getNumericCellValue());
				break;
			case HSSFCell.CELL_TYPE_STRING:
				dest.setCellValue(source.getStringCellValue());
				break;
		}
	}


	private void die(String message) {
		System.out.println(message);
		System.exit(1);
	}


	private void warn(String message) {
		System.out.println("WARNING: " + message);
	}


	private void info(String message) {
		System.out.println(message);
	}


	public String getDescription() {
		return "Options";
	}


	public CommandOption[] getOptions() {
		return opts;
	}


	public void optionMatched(CommandOption commandOption, String arg) {
	}

	static class TemplateExpression {
		private int row;
		private short col;
		private String expression;

		private static final String EXPRESSION_PREFIX = "\\{ss\\}\\:";
		public static final String EXPRESSION_THIS = EXPRESSION_PREFIX + "this";
		public static final String EXPRESSION_CELL = EXPRESSION_PREFIX + "cell\\((\\d+)\\:(\\d+)\\)";

		Matcher cell_matcher;


		public static boolean isTemplateExpression(String s) {
			if (s.matches(EXPRESSION_THIS) || s.matches(EXPRESSION_CELL)) return true;
			return false;
		}


		public TemplateExpression(int row, short col, String expression) {
			this.row = row;
			this.col = col;
			this.expression = expression;

			Pattern pattern = Pattern.compile(EXPRESSION_CELL);
			cell_matcher = pattern.matcher(expression);
		}


		public int getRow() {
			return row;
		}


		public short getCol() {
			return col;
		}


		public String getExpression() {
			return expression;
		}


		public int getExpressionRow() {
			if (expression.matches(EXPRESSION_THIS)) {
				return row;
			}
			if (cell_matcher.matches()) {
				return Integer.parseInt(cell_matcher.group(2)) - 1;
			}
			return -1;
		}


		public short getExpressionCol() {
			if (expression.matches(EXPRESSION_THIS)) {
				return col;
			}
			if (cell_matcher.matches()) {
				return (short) (Short.parseShort(cell_matcher.group(1)) - 1);
			}
			return -1;
		}

	}
}